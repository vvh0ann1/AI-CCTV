# Violence > 2024-02-03 6:21pm
https://universe.roboflow.com/project-28v2s/violence-damqf

Provided by a Roboflow user
License: CC BY 4.0

