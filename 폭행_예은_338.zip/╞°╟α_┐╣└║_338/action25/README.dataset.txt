# violence2 > 2024-02-03 7:45pm
https://universe.roboflow.com/project-28v2s/violence2

Provided by a Roboflow user
License: CC BY 4.0

