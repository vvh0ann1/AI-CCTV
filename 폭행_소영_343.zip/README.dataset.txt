# yolo > 2024-02-03 6:20pm
https://universe.roboflow.com/sozero-a3rdj/yolo-bvcw0

Provided by a Roboflow user
License: CC BY 4.0

