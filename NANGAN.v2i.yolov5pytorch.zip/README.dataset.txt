# NANGAN > 2024-02-01 12:25am
https://universe.roboflow.com/sunshin-womens-university/nangan-1yo4x

Provided by a Roboflow user
License: CC BY 4.0

