# nangan-all > 2024-02-03 4:03pm
https://universe.roboflow.com/detect-idu1q/nangan-all

Provided by a Roboflow user
License: CC BY 4.0

