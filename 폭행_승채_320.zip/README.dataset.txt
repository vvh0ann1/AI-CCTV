# fight > 2024-02-03 7:23pm
https://universe.roboflow.com/sunshin-womens-university/fight-tc6kj

Provided by a Roboflow user
License: CC BY 4.0

